﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;

namespace App4
{
    class FillDataModels
    {
        static List<ReportDataModel> listreports = new List<ReportDataModel>();
        public static List<ReportDataModel> JsonParser(String json)
        {
            Org.Json.JSONObject rootobject = new Org.Json.JSONObject(json);
            Org.Json.JSONArray jsonarray = rootobject.GetJSONArray("reports");
            for (int i = 0; i < jsonarray.Length(); i++)
            {
                Org.Json.JSONObject jsonn = jsonarray.GetJSONObject(i);
                listreports.Add(new ReportDataModel(""+jsonn.GetInt("id"),jsonn.GetString("title"),jsonn.GetString("registerDate")
                    ,""+jsonn.GetInt("status"),jsonn.GetString("description"),jsonn.GetString("username")));
                

            }
            

            return listreports;
        }
    }
}