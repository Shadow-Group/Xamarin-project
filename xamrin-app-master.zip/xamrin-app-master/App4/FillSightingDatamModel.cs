﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;

namespace App4
{
    class FillSightingDatamModel
    {
        private static List<SightingDataModel> listdatamodel = new List<SightingDataModel>();
        public static List<SightingDataModel> FillData(String json)
        {
            Org.Json.JSONObject rootjson = new Org.Json.JSONObject(json);
            Org.Json.JSONArray jsonarray = rootjson.GetJSONArray("sightings");
            for (int i = 0; i < jsonarray.Length(); i++)
            {
                Org.Json.JSONObject jsonobj = jsonarray.GetJSONObject(i); ;
                listdatamodel.Add(new SightingDataModel(jsonobj.GetString("face"),"" +jsonobj.GetInt("id"), jsonobj.GetString("username"),
                    jsonobj.GetString("date"), jsonobj.GetString("province"), jsonobj.GetString("city"), jsonobj.GetString("area"),
                    ""+jsonobj.GetInt("status")));
            }
           
            return listdatamodel;
        }
    }
}