﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;

namespace App4
{
    class CommonConstans
    {
        public  static  string URL = "http://fypserver1.azurewebsites.net/?";
        public static string OP_SIGN_IN = "signin";
        public static string OP_SIGN_UP = "signup";
        public static string OP_TENANT_REPORT = "tenantreport";
        public static string OP_COMPLAINT = "complaint";
        public static string OP_FIR= "fir";
        public static string OP_GET_REPORTS = "get_status";
        public static string OP_GET_SIGHTS = "get_sights";
        public static string SharedPrefsConfig = "config";
        public static User USER;

        public static class ConfigKeys{
            public static string LOGGED = "logged";
            public static string UID = "user_id";
            public static string USERNAME = "username";
            public static string PASSWORD = "password";
        }
        public static class ReportTypes{
            public static int FIR = 2;
            public static int COMPLAIN = 1;
        }
    }
}