﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;

namespace App4
{
    public class SightingDataModel
    {
        private String face;
        private String id;
        private String username;
        private String date;
        private String province;
        private String city;
        private String area;
        private String status;
        public String GetCity(){
            return city;
        }
        public void SetCity(string city)
        {
            this.city = city;
        }
        public SightingDataModel(String face, String id, String username, String date,
            String province, String city, String area, String status)
        {
            this.face = face;
            this.id = id;
            this.username = username;
            this.date = date;
            this.province = province;
            this.area = area;
            this.status = status;
        }
        public String GetFace()
        {
            return face;
        }
        public String GetId()
        {
            return id;
        }
        public String GetUserName()
        {
            return username;
        }
        public String GetDate()
        {
            return date;
        }
        public String GetProvince()
        {
            return province;
        }
        public String GetArea()
        {
            return area;
        }
        public String GetStatus()
        {
            return status;
        }
    }
}