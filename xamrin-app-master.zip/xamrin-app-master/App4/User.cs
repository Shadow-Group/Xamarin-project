﻿using System;
namespace App4
{
    public class User
    {
        private int id;
        private string name;
        private string password;
        public User()
        {
        }
        public int getId(){
            return id;
        }
        public void setId(int id){
            this.id = id;
        }
        public void setName(string name){
            this.name = name;
        }
        public string getName(){
            return name;
        }
        public string getPassword(){
            return password;
        }
        public void setPassword(string password){
            this.password = password;
        }
    }
}
