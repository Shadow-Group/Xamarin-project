﻿using System;
using Android.App;
using Android.Support.Design.Widget;
using Android.Views;

namespace App4
{
    public class ReportSubmitImpl : OnReportSubmitted
    {
		private View mView;
		private Activity activity;
		private ProgressDialog dialog;
        public ReportSubmitImpl(View view, ProgressDialog dailog, Activity act)
		{
			mView = view;
			this.dialog = dailog;
			this.activity = act;
		}
		public void onError()
		{
			dialog.Dismiss();
			Snackbar.Make(mView, "There is an error.", Snackbar.LengthLong).Show();
		}

		public void onSuccess()
		{
            dialog.Dismiss();

			Snackbar snackBar = Snackbar.Make(mView, "Successfully Submitted", Snackbar.LengthLong);

			snackBar.Show();

		}

    }
}
