﻿using System;
using System.Collections.Generic;
using System.IO;
using Android.Graphics;
using Android.Util;

namespace App4
{
    public class Utils
    {
		public static String BitMapToString(Bitmap bitmap)
		{
			MemoryStream baos = new MemoryStream();
            bitmap.Compress(Bitmap.CompressFormat.Jpeg, 100, baos);
			byte[] b = baos.ToArray();
			String temp = Base64.EncodeToString(b, Base64Flags.Default);
			return temp;
		}

        public static Bitmap StringToBitMap(String encodedString)
		{
			try
			{
                byte[] encodeByte = Base64.Decode(encodedString, Base64Flags.Default);
                Bitmap bitmap = BitmapFactory.DecodeByteArray(encodeByte, 0, encodeByte.Length);
				return bitmap;
			}
			catch (Exception e)
			{
				return null;
			}
		}
		public static List<string> SplitString(int chunk, string input)
		{
			List<string> list = new List<string>();
			int cycles = input.Length / chunk;

			if (input.Length % chunk != 0)
				cycles++;

			for (int i = 0; i < cycles; i++)
			{
				try
				{
					list.Add(input.Substring(i * chunk, chunk));
				}
				catch
				{
					list.Add(input.Substring(i * chunk));
				}
			}
			return list;
		}
    }
	
}
