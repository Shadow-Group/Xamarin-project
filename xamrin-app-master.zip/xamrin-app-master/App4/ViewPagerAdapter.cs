﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Support.V4.App;
using Android.Views;
using Android.Widget;

namespace App4
{
    public class ViewPagerAdapter : FragmentPagerAdapter
    {
        private Android.Support.V4.App.Fragment[] fragments;
        private string[] titles = { "Reports", "Sightings" };

        public ViewPagerAdapter(Android.Support.V4.App.FragmentManager fm,
                                Android.Support.V4.App.Fragment[] fragments):base(fm){
            this.fragments = fragments;

        }

        public override int Count => fragments.Length;

        public override Android.Support.V4.App.Fragment GetItem(int position)
        {
            return fragments[position];
        }
        public override Java.Lang.ICharSequence GetPageTitleFormatted(int position)
        {
            return new Java.Lang.String(titles[position]);
        }
    }
}