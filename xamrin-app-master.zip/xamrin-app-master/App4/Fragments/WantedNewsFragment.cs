﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Support.Design.Widget;
using Android.Support.V4.View;
using Android.Util;
using Android.Views;
using Android.Widget;

namespace App4
{
    public class WantedNewsFragment : Android.Support.V4.App.Fragment
    {
        private TabLayout tabLayout;
        private ViewPager viewPager;

        public override void OnCreate(Bundle savedInstanceState)
        {
            base.OnCreate(savedInstanceState);

            // Create your fragment here
        }

        public override View OnCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
        {
            // Use this to return your custom view for this Fragment
            // return inflater.Inflate(Resource.Layout.YourFragment, container, false);
            View view = inflater.Inflate(Resource.Layout.wanted_news_fragment, container, false);
            tabLayout = (TabLayout)view.FindViewById(Resource.Id.tabLayout);
            viewPager = (ViewPager)view.FindViewById(Resource.Id.viewpager);
            return view;
        }
        public override void OnActivityCreated(Bundle savedInstanceState)
        {
            base.OnActivityCreated(savedInstanceState);
            setupViewPager();
        }

        private void setupViewPager()
        {
            Android.Support.V4.App.Fragment[] fragments = new Android.Support.V4.App.Fragment[2];
            fragments[0] = new Fragments.ReportsFragment();
            fragments[1] = new Fragments.SightingFragment();
            viewPager.Adapter = new ViewPagerAdapter(ChildFragmentManager, fragments);
            tabLayout.SetupWithViewPager(viewPager);
        }
    }
}