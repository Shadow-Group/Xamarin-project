﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Util;
using Android.Views;
using Android.Widget;
using App4.Adapters;
using Android.Support.V7.Widget;

namespace App4.Fragments
{
    public class SightingFragment : Android.Support.V4.App.Fragment
    {
        private RecyclerView recyclerview;
        private RecyclerView.LayoutManager mLayoutManager;
        private Context context;
        private AdapterSighting adapter;
        private ProgressBar progressBar;
       
        public override void OnCreate(Bundle savedInstanceState)
        {
            base.OnCreate(savedInstanceState);

            GetJson abc = new GetJson(CommonConstans.OP_GET_SIGHTS, new ListenerA(this));
            abc.Execute();
            // Create your fragment here
        }
        public override void OnActivityCreated(Bundle savedInstanceState)
        {
            base.OnActivityCreated(savedInstanceState);
            context = Activity;
			mLayoutManager = new LinearLayoutManager(context);
			recyclerview.SetLayoutManager(mLayoutManager);
			adapter = new AdapterSighting();
			recyclerview.SetAdapter(adapter);
        }

        public override View OnCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
        {
            View view = inflater.Inflate(Resource.Layout.sightingfragmeny_layout, container, false);
            recyclerview = view.FindViewById<RecyclerView>(Resource.Id.recyclerViewsighting);
            progressBar = (ProgressBar)view.FindViewById(Resource.Id.progress_bar);

            return view;
        }
        public void NotifyChange(List<SightingDataModel> data){
            progressBar.Visibility = ViewStates.Gone;
            adapter.setData(data);
        }
    }

     class ListenerA : OnResponce
	{
        SightingFragment parent;
        public ListenerA(SightingFragment parent)
		{
			this.parent = parent;
		}
		public void OnError()
		{

		}

		public void OnSuccess(string json)
		{
            parent.NotifyChange(FillSightingDatamModel.FillData(json));
		}
	}
}