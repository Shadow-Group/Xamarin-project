﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Util;
using Android.Views;
using Android.Widget;
using Android.Support.V7.Widget;
using App4.Adapters;

namespace App4.Fragments
{
    public class ReportsFragment : Android.Support.V4.App.Fragment
    {
        private RecyclerView recyclerview;
        private RecyclerView.LayoutManager mLayoutManager;
        private Context context;
        private ReportsAdapter adapter;
        private List<ReportDataModel> data;
        private ProgressBar preogressBar;
       
        public override void OnCreate(Bundle savedInstanceState)
        {
            base.OnCreate(savedInstanceState);

            // Create your fragment here
            data = new List<ReportDataModel>();
            Listener listener = new Listener(this);
            GetJson abc=new GetJson(CommonConstans.OP_GET_REPORTS, listener);
            abc.Execute();        }
        public override void OnActivityCreated(Bundle savedInstanceState)
        {
            base.OnActivityCreated(savedInstanceState);
            context = Activity;
			mLayoutManager = new LinearLayoutManager(context);
			recyclerview.SetLayoutManager(mLayoutManager);
			adapter = new ReportsAdapter();
			recyclerview.SetAdapter(adapter);
        }

        public override View OnCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
        {
            View view = inflater.Inflate(Resource.Layout.reportsfragment_layout, container, false);
            recyclerview = view.FindViewById<RecyclerView>(Resource.Id.recyclerViewreports);
            preogressBar = (ProgressBar)view.FindViewById(Resource.Id.progress_bar);

            return view;
        }
        public void NotifyChange(List<ReportDataModel> dat){
            this.data = dat;
            preogressBar.Visibility = ViewStates.Gone;
            adapter.setData(data);

        }
    }
    class Listener : OnResponce
    {
        ReportsFragment parent;
        public Listener(ReportsFragment parent){
            this.parent = parent;
        }
        public void OnError()
        {

        }

        public void OnSuccess(string json)
        {
            parent.NotifyChange(FillDataModels.JsonParser(json));
        }
    }
}