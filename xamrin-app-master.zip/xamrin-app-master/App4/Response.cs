﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;

namespace App4
{
    class Response
    {
        private int code;
        private string comment;
        public int GetCode()
        {
            return code;
        }
        public void SetCode(int rresponse)
        {
            code = rresponse;
        }
        public string GetComment()
        {
            return comment;
        }
        public void SetComment(string commnt)
        {

            comment = commnt;
        }



    }
}