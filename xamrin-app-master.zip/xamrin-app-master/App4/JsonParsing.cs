﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;


namespace App4
{
    class JsonParsing
    {
       

        public Response Jsonparse(string json)
        {
            Response re = new Response();
            Org.Json.JSONObject jsonn = new Org.Json.JSONObject(json);
            Org.Json.JSONObject jo = jsonn.GetJSONObject("message");
            re.SetCode(jo.GetInt("code"));
            re.SetComment(jo.GetString("comment"));
            return re;

           
        }

    }
}