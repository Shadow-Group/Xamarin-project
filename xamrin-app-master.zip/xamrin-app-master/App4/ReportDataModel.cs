﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;

namespace App4
{
    public class ReportDataModel
    {
        private String caseId;
        private String title;
        private String registerDate;
        private String status;
        private String description;
        private String username;
        public ReportDataModel(String caseid,String title,String registerDate,String status,String description,String username)
        {
            this.caseId = caseid;
            this.title = title;
            this.registerDate = registerDate;
            this.status = status;
            this.description = description;
            this.username = username;

        }
        public String GetCaseId()
        {
            return caseId;

        }
        public String GetTitle()
        {
            return title;

        }
        public String GetRegisterDate()
        {
            return registerDate;

        }
        public String GetStatus()
        {
            return status;

        }
        public String GetDescrpition()
        {
            return description;

        }
        public String GetUserName()
        {
            return username;

        }

    }
}