﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using Android.Support.V7.Widget;

namespace App4.Adapters
{
    class ReportsAdapter : RecyclerView.Adapter
    {
        private List<ReportDataModel> data;

        public ReportsAdapter()
        {
            data = new List<ReportDataModel>();
        }

        public override int ItemCount => data.Count;

        public override void OnBindViewHolder(RecyclerView.ViewHolder holder, int position)
        {
            ReportsAdapter.Holder myholder = (ReportsAdapter.Holder)holder;
            ReportDataModel model = data[position];
            myholder.status.Text = model.GetStatus();
            myholder.title.Text = model.GetTitle();
            myholder.description.Text = model.GetDescrpition();
            myholder.date.Text = model.GetRegisterDate();

        }

        public override RecyclerView.ViewHolder OnCreateViewHolder(ViewGroup parent, int viewType)
        {
            View view = LayoutInflater.From(parent.Context).
                Inflate(Resource.Layout.firreports, parent, false);
            return new Holder(view);
        }

        public class Holder : RecyclerView.ViewHolder
        {
            public TextView title;
            public TextView description;
            public TextView status;
            public TextView date;
            public Holder(View itemView) : base(itemView)
            {
                title = itemView.FindViewById<TextView>(Resource.Id.titlereports_textview);
                description = itemView.FindViewById<TextView>(Resource.Id.descriptionreport_textview);
                status = itemView.FindViewById<TextView>(Resource.Id.statusreport_textview);
                date = itemView.FindViewById<TextView>(Resource.Id.registerdatereport_textview);

            }

        }

        internal void setData(List<ReportDataModel> data)
        {
            this.data = data;
            NotifyDataSetChanged();
        }
    }
}