﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using Android.Support.V7.Widget;
using Android.Graphics;

namespace App4.Adapters
{
    class AdapterSighting : RecyclerView.Adapter
    {
        private List<SightingDataModel> data;
        public AdapterSighting()
        {
            data = new List<SightingDataModel>();
        }
        public override int ItemCount => data.Count;

        public override void OnBindViewHolder(RecyclerView.ViewHolder holder, int position)
        {
            AdapterSighting.Holder myHolder = (AdapterSighting.Holder)holder;
            SightingDataModel model = data[position];
            myHolder.username.Text = model.GetUserName();
            myHolder.status.Text = model.GetStatus();
            myHolder.province.Text = model.GetProvince();
            myHolder.city.Text = model.GetCity();
            myHolder.area.Text = model.GetArea();
            string face = model.GetFace();
            Bitmap bitmap = Utils.StringToBitMap(face);
            if (bitmap != null)
            {
                myHolder.sightingimage.SetImageBitmap(bitmap);
            }
        }

        public override RecyclerView.ViewHolder OnCreateViewHolder(ViewGroup parent, int viewType)
        {
            View view = LayoutInflater.From(parent.Context).
               Inflate(Resource.Layout.reportslayout, parent, false);
            return new Holder(view);
        }
        public class Holder : RecyclerView.ViewHolder
        {
            public ImageView sightingimage;

            public TextView username;
            public TextView province;
            public TextView city;
            public TextView area;
            public TextView status;
            public Holder(View itemView) : base(itemView)
            {
                sightingimage = itemView.FindViewById<ImageView>(Resource.Id.Sighting_iamgeviewse);
                username = itemView.FindViewById<TextView>(Resource.Id.usernamesight_textview);
                province = itemView.FindViewById<TextView>(Resource.Id.provincesight_textview);
                city = itemView.FindViewById<TextView>(Resource.Id.citysight_textview);
                area = itemView.FindViewById<TextView>(Resource.Id.areasight_textview);
                status = itemView.FindViewById<TextView>(Resource.Id.statusidsight_textview);


            }

        }
        public void setData(List<SightingDataModel> data){
            this.data = data;
            NotifyDataSetChanged();
        }
    }
}