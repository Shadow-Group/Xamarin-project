﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using Android.Provider;
using Android.Graphics;
using Android.Text;

namespace App4.Activities
{
    [Activity(Label = "SightingActivity")]
    public class SightingActivity : Activity
    {
        private Button uploadbtn;
        private EditText description;
        private EditText location;
        private ImageView uploadimgview;
        private Button submitbtn;
        private Bitmap selectedImage;
        private Dialog dialog;
        private EditText provinceEditText;
        protected override void OnCreate(Bundle savedInstanceState)
        {
            base.OnCreate(savedInstanceState);
            this.Window.AddFlags(WindowManagerFlags.DrawsSystemBarBackgrounds);
            SetContentView(Resource.Layout.sightinglayout);
            TextView logotextview = FindViewById<TextView>(Resource.Id.sightinglogotextview);
            uploadbtn = FindViewById<Button>(Resource.Id.upload_button);
            uploadimgview = FindViewById<ImageView>(Resource.Id.uploadImageView);
            description = FindViewById<EditText>(Resource.Id.sightingdescription_edittext);
            location = FindViewById<EditText>(Resource.Id.sightinglocation_edittext);
            provinceEditText = FindViewById<EditText>(Resource.Id.province_edit_text);
            submitbtn = FindViewById<Button>(Resource.Id.submitsighting_button);
            Typeface tt = Typeface.CreateFromAsset(Assets, "fonts.ttf");
            logotextview.SetTypeface(tt, TypefaceStyle.Normal);
            submitbtn.Click += Submitbtn_Click;
            uploadbtn.Click += Uploadbtn_Click;

            // Create your application here
        }

        private void Submitbtn_Click(object sender, EventArgs e)
        {
            Boolean checkEdittext = ValidateEditText(new EditText[] { description, location });
            Boolean checkImageview = ValidateImageView();
            if(provinceEditText.Text.Length<1){
                provinceEditText.Error = "Please provide province.";
                return;
            }
            if (checkEdittext && checkImageview)
            {
                string area = location.Text.ToString();
                string city = this.description.Text.ToString();
                if(selectedImage==null){
                    Toast.MakeText(this,"hello",ToastLength.Long).Show();
                }
                string face = Utils.BitMapToString(selectedImage);
                string province = provinceEditText.Text.ToString();

                ProgressDialog progressDialog = new ProgressDialog(this, Resource.Style.AppCompatDialogStyle);
				progressDialog.SetCancelable(false);
				progressDialog.SetMessage("Please wait....");
				progressDialog.SetTitle("Submiting");
				progressDialog.Indeterminate = true;
				progressDialog.Show();

                ReportSubmitImpl callback = new ReportSubmitImpl(this.description, progressDialog, this);
                SubmitOperationHandler.submitSighting(CommonConstans.USER, province, city, area, face,callback);

            }
        }

        private void Uploadbtn_Click(object sender, EventArgs e)
        {
            //Custom fragment for choosing image from gallery or from camera 
            SetDialog();

            
        }
        protected override void OnActivityResult(int requestCode, Result resultCode, Intent data)
        {
            base.OnActivityResult(requestCode, resultCode, data);
            if (requestCode == 0)
            {
                if (resultCode == Result.Ok)
                {

                   uploadimgview.SetImageURI(data.Data);
					uploadimgview.BuildDrawingCache();
					selectedImage = uploadimgview.DrawingCache;
					uploadimgview.BuildDrawingCache(false);
                  //  selectedImage = Bit
                   // uploadimgview.SetImageBitmap(selectedImage);
                }
            }
            else if (requestCode == 1)
            {
                if (resultCode == Result.Ok)
                {
                    uploadimgview.SetImageURI(data.Data);
                    uploadimgview.BuildDrawingCache();
                    selectedImage = uploadimgview.DrawingCache;
                    uploadimgview.BuildDrawingCache(false);
					//selectedImage = (Bitmap)data.Extras.Get("data");
                    //uploadimgview.SetImageBitmap(selectedImage);

				}
            }
        }
        private void ImageFromGallery()
        {
            var imageIntent = new Intent();
            imageIntent.SetType("image/*");
            imageIntent.SetAction(Intent.ActionGetContent);
            StartActivityForResult(
                Intent.CreateChooser(imageIntent, "Select photo"), 0);
            dialog.Cancel();

        }
        private void ImageFromCamera()
        {

            Intent intent = new Intent(MediaStore.ActionImageCapture);
            StartActivityForResult(intent, 1);
            dialog.Cancel();
        }
        private Boolean ValidateEditText(EditText[] edit)
        {
            for (int i = 0; i < edit.Length; i++)
            {
                if (TextUtils.IsEmpty(edit[i].Text))
                {
                    edit[i].SetError("Can't be empty", GetDrawable(Resource.Drawable.error_ic));
                    return false;
                }
            }

            return true; ;
        }
        private Boolean ValidateImageView()
        {
            if (uploadimgview.GetDrawableState()==null)
            {
                return false;
            }
            else
            return true;
        }
        private void SetDialog()
        {
            dialog = new Dialog(this, Resource.Style.AppCompatDialogStyle);
            dialog.SetContentView(Resource.Layout.customdialog);
            TextView camera = dialog.FindViewById<TextView>(Resource.Id.cameratxt);
            TextView gallery = dialog.FindViewById<TextView>(Resource.Id.gallerytxt);
            camera.Click += Camera_Click;
            gallery.Click += Gallery_Click;
            dialog.Show();
        }

        private void Gallery_Click(object sender, EventArgs e)
        {
            ImageFromGallery();
        }

        private void Camera_Click(object sender, EventArgs e)
        {
            ImageFromCamera();
        }
    }
}