﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Support.V7.App;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using Android.Graphics;
using Android.Support.Design.Widget;
using Java.Util;
using Android.Text;

namespace App4
{
    [Activity(Label = "Signup", Theme = "@style/MyTheme")]
    public class SignupActivity : AppCompatActivity
    {

        private Spinner spinner;
        private Button dobbtn;
        private TextView textview;
        private Button submitbtn;
        private EditText name_edittxt;
        private EditText password_edittxt;
        private EditText contact_edittxt;
        private EditText zipcode_edittxt;
        private EditText adress_edittxt;
        private EditText email_edittxt;
        private EditText cnic_edittxt;
        private string mUsername;
        private string mAge;
        private string mDob;
        private ProgressDialog progressDialog;
        private Dictionary<string, string> mydictionary = new Dictionary<string, string>();

        protected override void OnCreate(Bundle savedInstanceState)
        {

            base.OnCreate(savedInstanceState);
            SetContentView(Resource.Layout.Signup);
            //
            TextView tx = FindViewById<TextView>(Resource.Id.alreadytxtview);
            dobbtn = FindViewById<Button>(Resource.Id.signupdob_btn);
            spinner = FindViewById<Spinner>(Resource.Id.signupgender_spinner);
            name_edittxt = FindViewById<EditText>(Resource.Id.signupname_edittext);
            password_edittxt = FindViewById<EditText>(Resource.Id.signuppassword_edittext);
            contact_edittxt = FindViewById<EditText>(Resource.Id.signupcontact_edittext);
            cnic_edittxt = FindViewById<EditText>(Resource.Id.signupcnic_edittext);
            adress_edittxt = FindViewById<EditText>(Resource.Id.signupaddress_edittext);
            zipcode_edittxt = FindViewById<EditText>(Resource.Id.signupzipcode_edittext);
            email_edittxt = FindViewById<EditText>(Resource.Id.signupemail_edittext);
            submitbtn = FindViewById<Button>(Resource.Id.signup_btn);
            //Here's set the custom Font 
            TextView tx1 = FindViewById<TextView>(Resource.Id.signuplogotextview);
            Typeface tt = Typeface.CreateFromAsset(Assets, "fonts.ttf");
            tx1.SetTypeface(tt, TypefaceStyle.Normal);
            //Spinner
            spinner.ItemSelected += new EventHandler<AdapterView.ItemSelectedEventArgs>(spinner_ItemSelected);
            var adapter = ArrayAdapter.CreateFromResource(
                   Application.Context, Resource.Array.gender, Android.Resource.Layout.SimpleSpinnerItem);

            int count = 0;
            adapter.SetDropDownViewResource(Android.Resource.Layout.SimpleSpinnerDropDownItem);
            spinner.Adapter = adapter;
            spinner.SetSelection(count);
            //Onclick listener for TextView of Have an account
            tx.Click += Tx_Click;
            dobbtn.Click += Dobbtn_Click;
            //Onclick listener for submit Button
            submitbtn.Click += MSubmitbtn_Click;

        }

        private void MSubmitbtn_Click(object sender, EventArgs e)
        {
            Boolean edit = ValidateEdittext(new EditText[] { name_edittxt, password_edittxt, cnic_edittxt, adress_edittxt, email_edittxt, zipcode_edittxt, contact_edittxt });
            Boolean spner = ValidateDob();
            if (edit == true && spner == true)
            {
                mydictionary.Clear();
                mydictionary.Add("username", email_edittxt.Text.ToString());
                mydictionary.Add("password", password_edittxt.Text.ToString());
                mydictionary.Add("name", name_edittxt.Text.ToString());
                mydictionary.Add("cnic", cnic_edittxt.Text.ToString());
                mydictionary.Add("gender", textview.Text);
                mydictionary.Add("age", mAge);
                mydictionary.Add("dob", mDob);
                mydictionary.Add("contact", contact_edittxt.Text.ToString());
                mydictionary.Add("email", email_edittxt.Text.ToString());
                mydictionary.Add("address", adress_edittxt.Text.ToString());
                mydictionary.Add("zip", zipcode_edittxt.Text.ToString());
                progressDialog = new ProgressDialog(this,Resource.Style.AppCompatDialogStyle);
                progressDialog.SetCancelable(false);
                progressDialog.SetMessage("Please wait....");
                progressDialog.SetTitle("Signup");
                progressDialog.Indeterminate = true;
                progressDialog.Show();
                Listener abc = new Listener(submitbtn, progressDialog,this);
                new UploadData(mydictionary, CommonConstans.OP_SIGN_UP, abc).Execute();




            }
        }

        private void Dobbtn_Click(object sender, EventArgs e)
        {
            Datepicker frag = Datepicker.NewInstance(delegate (DateTime time)
            {
                DateTime time1 = DateTime.Today;
                TimeSpan duration = time1 - time;
                int age = Convert.ToInt32((duration.TotalDays) / 365);
                if (age > 18)
                {
                   
                  
                    mDob = String.Format("{0:s}", time);
                    dobbtn.Text = time.ToString("yyyy-MM-dd");
                    mDob = time.ToString("yyyy-MM-dd");

                    mAge = age.ToString();

                }
                else
                {
                    Snackbar snackBar = Snackbar.Make(dobbtn, "You must be 18+ to register for this app.", Snackbar.LengthShort);
                    snackBar.Show();
                }

            });
            frag.Show(FragmentManager, Datepicker.TAG);


        }

        private void Tx_Click(object sender, EventArgs e)
        {
            //Start the SignInActivity
            StartActivity(typeof(SignInActivity));
        }
        private void spinner_ItemSelected(object sender, AdapterView.ItemSelectedEventArgs e)//From spinner item is selected
        {

            Spinner spinner = (Spinner)sender;
            textview = (TextView)e.View;

            textview.SetTextAppearance(Resource.Style.color);
            if (e.Position > 0) {

                spinner.SetSelection(e.Position);

            }
            else
            {
                Toast.MakeText(this, "please select Gender!", ToastLength.Short).Show();
            }




        }
        private Boolean ValidateEdittext(EditText[] edittxt)
        {
            for (int i = 0; i < edittxt.Length; i++)
            {
                if (TextUtils.IsEmpty(edittxt[i].Text))
                {
                    edittxt[i].SetError("Can't be empty", GetDrawable(Resource.Drawable.error_ic));
                    return false;
                }
            }
            return true;

        }
        private Boolean ValidateDob()
        {
            if (dobbtn.Text == "DOB")
            {
                Snackbar snackBar = Snackbar.Make(dobbtn, "Please enter your DOB", Snackbar.LengthShort);
                snackBar.Show();
                return false;
            }
            else if (textview.Text == "Gender")
            {
                Snackbar snackBar = Snackbar.Make(dobbtn, "Please Select the gender", Snackbar.LengthShort);
                snackBar.Show();
                return false;
            }

            return true;
        }
        private class Listener : OnResult
        {
            private View mView;
            private Activity activity;
            private ProgressDialog dialog;
            public Listener(View view, ProgressDialog dailog,Activity act)
            {
                mView = view;
                this.dialog = dailog;
                this.activity = act;
            }
            public void onError(string error)
            {
                dialog.Dismiss();
                Snackbar.Make(mView, "There is an error.", Snackbar.LengthLong).Show();
            }

            public void onSuccess(string result)
            {
                JsonParsing jsonparsing = new JsonParsing();

                Response response = jsonparsing.Jsonparse(result);
                Snackbar snackBar;
                dialog.Dismiss();
                if (response.GetCode() == 200)
                {
                    snackBar = Snackbar.Make(mView, "Successfully Sign Up", Snackbar.LengthLong);
                    snackBar.SetAction("Login", (obj) => {
                        activity.StartActivity(typeof(SignInActivity));
                        activity.Finish();
                    });
                    snackBar.Show();

                }

                else
                {

                    snackBar = Snackbar.Make(mView, "Unable to Sign Up. Email already resgistered", Snackbar.LengthShort);
                    snackBar.Show();

                }

            }
        }
    }
}