﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using Android.Support.V7.App;
using Android.Graphics;
using Android.Text;
using Android.Support.Design.Widget;

namespace App4.Activities
{
    [Activity(Label = "FirActivity")]
    public class FirActivity : AppCompatActivity
    {
        private EditText title_edittxt;
        private EditText description_edittxt;
        private ProgressDialog progressDialog;
        private Button submitbutton;
        protected override void OnCreate(Bundle savedInstanceState)
        {
            base.OnCreate(savedInstanceState);
            this.Window.AddFlags(WindowManagerFlags.DrawsSystemBarBackgrounds);
            SetContentView(Resource.Layout.firlayout);
            TextView firlogotx = FindViewById<TextView>(Resource.Id.firlogotextview);
            Typeface tt = Typeface.CreateFromAsset(Assets, "fonts.ttf");
            firlogotx.SetTypeface(tt, TypefaceStyle.Normal);
            submitbutton = FindViewById<Button>(Resource.Id.firsubmit_btn);
            title_edittxt = FindViewById<EditText>(Resource.Id.firtitle_edittext);
            description_edittxt = FindViewById<EditText>(Resource.Id.firdescription_edittext);
            submitbutton.Click += Submitbutton_Click;

            // Create your application here
        }


        private void Submitbutton_Click(object sender, EventArgs e)
        {

            Boolean editcheck = ValidateEdittext(new EditText[] { title_edittxt, description_edittxt });
            if (editcheck)
            {
                string title = title_edittxt.Text.ToString();
                string description = description_edittxt.Text.ToString();
                int type = CommonConstans.ReportTypes.FIR;

                progressDialog = new ProgressDialog(this, Resource.Style.AppCompatDialogStyle);
                progressDialog.SetCancelable(false);
                progressDialog.SetMessage("Please wait....");
                progressDialog.SetTitle("Submiting");
                progressDialog.Indeterminate = true;
                progressDialog.Show();
                ReportSubmitImpl abc = new ReportSubmitImpl(submitbutton, progressDialog, this);
                SubmitOperationHandler.submitFirOrComplaint(CommonConstans.USER, type, title, description, abc);
            }
        }
        private Boolean ValidateEdittext(EditText[] edit)
        {
            for (int i = 0; i < edit.Length; i++)
            {
                if (TextUtils.IsEmpty(edit[i].Text))
                {
                    edit[i].SetError("Can't be empty", GetDrawable(Resource.Drawable.error_ic));
                    return false;
                }
            }
            return true;



        }
      
    }
}