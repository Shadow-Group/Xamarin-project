﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using Android.Support.V7.App;
using Android.Graphics;
using Android.Text;
using Android.Support.Design.Widget;

namespace App4.Activities
{
    [Activity(Label = "ComplaintActivity")]
    public class ComplaintActivity : AppCompatActivity
    {
        private EditText title_edittext;
        private EditText description_edittext;
        private Button submitbutton;
        private ProgressDialog progressDialog;
        private Dictionary<string, string> mydictionary = new Dictionary<string, string>();
        protected override void OnCreate(Bundle savedInstanceState)
        {
            base.OnCreate(savedInstanceState);
            this.Window.AddFlags(WindowManagerFlags.DrawsSystemBarBackgrounds);
            SetContentView(Resource.Layout.complaintlayout);
            TextView tx1 = FindViewById<TextView>(Resource.Id.complaintlogotextview);
            Typeface tt = Typeface.CreateFromAsset(Assets, "fonts.ttf");
            tx1.SetTypeface(tt, TypefaceStyle.Normal);
            title_edittext = FindViewById<EditText>(Resource.Id.complianttitle_edittext);
            description_edittext = FindViewById<EditText>(Resource.Id.compliantdescription_edittext);
            submitbutton = FindViewById<Button>(Resource.Id.complaintsubmit_btn);
            submitbutton.Click += Submitbutton_Click;

            // Create your application here
        }

        private void Submitbutton_Click(object sender, EventArgs e)
        {
            Boolean editcheck = ValidateEditText(new EditText[] { title_edittext, description_edittext });
            if (editcheck)
            {
                string title = title_edittext.Text.ToString();
                string description = description_edittext.Text.ToString();
				int type = CommonConstans.ReportTypes.COMPLAIN;

				progressDialog = new ProgressDialog(this, Resource.Style.AppCompatDialogStyle);
				progressDialog.SetCancelable(false);
				progressDialog.SetMessage("Please wait....");
				progressDialog.SetTitle("Submiting");
				progressDialog.Indeterminate = true;
				progressDialog.Show();
				ReportSubmitImpl abc = new ReportSubmitImpl(submitbutton, progressDialog, this);
				SubmitOperationHandler.submitFirOrComplaint(CommonConstans.USER, type, title, description, abc);
            }

        }
        private Boolean ValidateEditText(EditText[] edit)
        {
            for (int i = 0; i < edit.Length; i++)
                if (TextUtils.IsEmpty(edit[i].Text))
                {
                    edit[i].SetError("Can't be empty", GetDrawable(Resource.Drawable.error_ic));
                    return false;
                }

            return true;
        }

    }
}