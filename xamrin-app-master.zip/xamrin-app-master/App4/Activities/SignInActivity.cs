﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.App;
using Android.Support.V7.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using Android.Graphics;
using NavigationDrawer;
using Android.Text;
using Android.Support.Design.Widget;

namespace App4
{
    [Activity(Label = "SignInActivity", MainLauncher = false)]
    public class SignInActivity : AppCompatActivity
    {
       private EditText username_edittxt;
        private EditText password_edittxt;
        private Button loginbtn;
        ProgressDialog progressDialog;
        private Dictionary<string, string> mydictionary = new Dictionary<string, string>();
        protected override void OnCreate(Bundle savedInstanceState)
        {
            base.OnCreate(savedInstanceState);
            SetContentView(Resource.Layout.signinlayout);
          
        
            TextView noaccounttxt = FindViewById<TextView>(Resource.Id.noaccounttextview);
            TextView logotxt = FindViewById<TextView>(Resource.Id.logintextview);
            username_edittxt = FindViewById<EditText>(Resource.Id.loginusername_edittext);
            password_edittxt = FindViewById<EditText>(Resource.Id.loginpassword_edittext);
            Typeface tt = Typeface.CreateFromAsset(Assets, "fonts.ttf");
            logotxt.SetTypeface(tt,TypefaceStyle.Normal);
            loginbtn = FindViewById<Button>(Resource.Id.signin_button);
            password_edittxt.Click += Password_edittxt_Click;
            loginbtn.Click += Loginbtn_Click;
            noaccounttxt.Click += Tx_Click;
            // Create your application here
        }

        private void Password_edittxt_Click(object sender, EventArgs e)
        {
           
        }

        private void Loginbtn_Click(object sender, EventArgs e)
        {
            Boolean check;
            check = ShowError(new EditText[] { username_edittxt, password_edittxt });
            if (check)
            {
                mydictionary.Clear();   
                mydictionary.Add("username", username_edittxt.Text.ToString());
                mydictionary.Add("password", password_edittxt.Text.ToString());

                progressDialog = new ProgressDialog(this,Resource.Style.AppCompatDialogStyle);
                progressDialog.SetCancelable(false);
                progressDialog.SetMessage("Checking login please wait!!!");
                progressDialog.SetTitle("Login");
                progressDialog.Indeterminate = true;
                progressDialog.Show();
                                                    Listener abc = new Listener(loginbtn, progressDialog,this,username_edittxt.Text.ToString(),password_edittxt.Text.ToString());
				new UploadData(mydictionary,CommonConstans.OP_SIGN_IN,abc).Execute();
             
            }
        }

        private void Tx_Click(object sender, EventArgs e)
        {
            StartActivity(typeof(SignupActivity));
        }

        public override void OnBackPressed()
        {
            Finish();
        }
        private Boolean ShowError(EditText[] edit)
        {
            for (int i = 0; i < edit.Length; i++)
                {
                if (TextUtils.IsEmpty(edit[i].Text))
                {
                    edit[i].SetError("Can't be empty ",GetDrawable(Resource.Drawable.error_ic));
                    return false;
                }
                
            }
            return true;
        }
        private class Listener : OnResult
        {
            private View mView;
            private ProgressDialog dialog;
            private Activity activity;
            private string username;
            private string password;
                    public Listener(View view,ProgressDialog dailog,Activity act,string user,string pass){
                mView = view;
                this.dialog = dailog;
                this.activity = act;
                this.username = user;
                this.password = pass;
            }
            public void onError(string error)
            {
                dialog.Dismiss();
                Snackbar.Make(mView,"There is an error.",Snackbar.LengthLong).Show();
            }

            void OnResult.onSuccess(string result)
            {
                JsonParsing jsonparsing = new JsonParsing();

                Response response = jsonparsing.Jsonparse(result);
                Snackbar snackBar;
                dialog.Dismiss();
                if (response.GetCode() == 200)
                {
                    //save in shared prefs
                    activity.GetSharedPreferences(CommonConstans.SharedPrefsConfig,
                                                  Android.Content.FileCreationMode.Private
                                                 )
                            .Edit()
                            .PutBoolean(CommonConstans.ConfigKeys.LOGGED, true)
                            .PutString(CommonConstans.ConfigKeys.USERNAME,username)
                            .PutString(CommonConstans.ConfigKeys.PASSWORD,password)
                            .PutInt(CommonConstans.ConfigKeys.UID,new Org.Json.JSONObject(result).GetJSONObject("data").GetInt("id"))
                            .Apply();
                    activity.StartActivity(typeof(MainActivity));
                    activity.Finish();

                }

                else
                {

                    snackBar = Snackbar.Make(mView, "Unable to Sign In", Snackbar.LengthShort);
                    snackBar.Show();

                }

            }
        }
    }

    
}