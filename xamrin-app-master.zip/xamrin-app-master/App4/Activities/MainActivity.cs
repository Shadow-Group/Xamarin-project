﻿using Android.Widget;
using Android.OS;
using Android.Support.Design.Widget;
using Android.Support.V4.Widget;
using Android.Support.V7.Widget;
using Android.Support.V7.App;
using Android.Views;
using Android.App;
using App4;
using System;
using App4.Activities;

namespace NavigationDrawer
{
	[Activity (Label = "Home", MainLauncher = true, Icon = "@mipmap/icon", Theme = "@style/MyTheme")]
	public class MainActivity : AppCompatActivity
	{
       
        private Android.Support.V7.Widget.Toolbar toolbar;
		private DrawerLayout drawerLayout;
        Android.Support.V4.App.Fragment[] fragments;
		protected override void OnCreate (Bundle savedInstanceState)
		{



			base.OnCreate (savedInstanceState);

            //check if user is logged in
            if(!GetSharedPreferences(CommonConstans.SharedPrefsConfig,
                                    Android.Content.FileCreationMode.Private).
               GetBoolean(CommonConstans.ConfigKeys.LOGGED, false)){
                StartActivity(typeof(SignInActivity));
                Finish();
            }
            Android.Content.ISharedPreferences prefs = GetSharedPreferences(
                CommonConstans.SharedPrefsConfig, Android.Content.FileCreationMode.Private
            );
            CommonConstans.USER = new User();
            CommonConstans.USER.setId(prefs.GetInt(CommonConstans.ConfigKeys.UID,-1));
            CommonConstans.USER.setName(prefs.GetString(CommonConstans.ConfigKeys.USERNAME,null));
            CommonConstans.USER.setPassword(prefs.GetString(CommonConstans.ConfigKeys.PASSWORD,null));
            
		    SetContentView (Resource.Layout.Main);
            toolbar = FindViewById<Android.Support.V7.Widget.Toolbar>(Resource.Id.app_bar);
            SetSupportActionBar(toolbar);
            drawerLayout = FindViewById<DrawerLayout>(Resource.Id.drawer_layout);
            SetToolbar();
			// Attach item selected handler to navigation view
			var navigationView = FindViewById<NavigationView>(Resource.Id.nav_view);
			navigationView.NavigationItemSelected += NavigationView_NavigationItemSelected;

			// Create ActionBarDrawerToggle button and add it to the toolbar
			var drawerToggle = new ActionBarDrawerToggle(this, drawerLayout, toolbar, Resource.String.open_drawer, Resource.String.close_drawer);
            drawerLayout.AddDrawerListener(drawerToggle);
			drawerToggle.SyncState();
            changeFragment();
		}
		//define custom title text
		protected override void OnResume ()
		{ 
			SupportActionBar.SetTitle (Resource.String.app_name);
			base.OnResume ();
		}

        void changeFragment()
        {
            Android.Support.V4.App.Fragment fragment=null;
            fragment = new WantedNewsFragment();
            var ft = SupportFragmentManager.BeginTransaction();
            ft.Replace(Resource.Id.homeFrameLayout, fragment);
            ft.Commit();


        }
		//define action for navigation menu selection
		void NavigationView_NavigationItemSelected(object sender, NavigationView.NavigationItemSelectedEventArgs e)
		{
			switch (e.MenuItem.ItemId)
			{
			case (Resource.Id.nav_inbox):
                    changeFragment();
                    SetToolbar();
				break;
			case (Resource.Id.nav_fir):
                    StartActivity(typeof(FirActivity));
                    
				break;
			case (Resource.Id.nav_complaint):
                    StartActivity(typeof(ComplaintActivity));

                    break;
                case (Resource.Id.nav_tenant):
                    StartActivity(typeof(TenantReport));
                    break;
                case Resource.Id.nav_sighting:
                    StartActivity(typeof(SightingActivity));
                    break;
                 
			}
			// Close drawer
			drawerLayout.CloseDrawers();
		}

		//add custom icon to tolbar
		public override bool OnCreateOptionsMenu (Android.Views.IMenu menu)
		{
			MenuInflater.Inflate (Resource.Menu.action_menu,menu);
			if (menu != null) { 
				menu.FindItem (Resource.Id.action_refresh).SetVisible (false); 
				menu.FindItem (Resource.Id.action_attach).SetVisible (false);
			}
			return base.OnCreateOptionsMenu (menu);
		}
		//define action for tolbar icon press
		public override bool OnOptionsItemSelected (IMenuItem item)
		{
			switch (item.ItemId)
			{
			case Android.Resource.Id.Home:
				//this.Activity.Finish();
				return true; 
			case Resource.Id.action_attach:
				//FnAttachImage();
				return true;
			default:
				return base.OnOptionsItemSelected(item);
			}
		}
		//to avoid direct app exit on backpreesed and to show fragment from stack
		public override void OnBackPressed ()
		{
           
			if(FragmentManager.BackStackEntryCount!= 0) {
				FragmentManager.PopBackStack ();// fragmentManager.popBackStack();
			} else {
				base.OnBackPressed ();
			}  
		}
        private void SetToolbar()
        {
            SupportActionBar.SetTitle(Resource.String.homestring);
            SupportActionBar.SetDisplayHomeAsUpEnabled(true);
            SupportActionBar.SetDisplayShowHomeEnabled(true);
        }
	}
   
}


