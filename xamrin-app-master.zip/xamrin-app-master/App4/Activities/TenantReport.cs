﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using Android.Support.Design.Widget;
using Android.Support.V7.App;
using Android.Graphics;
using Android.Text;

namespace App4.Activities
{
    [Activity(Label = "TenantReport")]
    public class TenantReport : AppCompatActivity
    {
       
        private EditText tenantresidence_edittext;
        private EditText tenantduration_edittext;
        private EditText tenatrent_edittext;
        private Button tenantsubmit_button;
        private TextView textview;
        private string mAge;
        private string mDob;
        private ProgressDialog progressDialog;
        protected override void OnCreate(Bundle savedInstanceState)
        {
            base.OnCreate(savedInstanceState);
            this.Window.AddFlags(WindowManagerFlags.DrawsSystemBarBackgrounds);
            SetContentView(Resource.Layout.tenantlayout);
            TextView tx1 = FindViewById<TextView>(Resource.Id.tenantlogotextview);
            Typeface tt = Typeface.CreateFromAsset(Assets, "fonts.ttf");
            tx1.SetTypeface(tt, TypefaceStyle.Normal);
           
            tenantresidence_edittext = FindViewById<EditText>(Resource.Id.tenantresidence_edittext);
            tenantduration_edittext = FindViewById<EditText>(Resource.Id.teanantduration_edittext);
            tenatrent_edittext = FindViewById<EditText>(Resource.Id.tenantrent_edittext);
            tenantsubmit_button = FindViewById<Button>(Resource.Id.tenantsubmit_btn);
            tenantsubmit_button.Click += Tenantsubmit_button_Click;



            // Create you111r application here
        }


        private void Tenantsubmit_button_Click(object sender, EventArgs e)
        {
            Boolean editxt=ValidateEditetxt(new EditText[] {tenantresidence_edittext,tenantduration_edittext,tenatrent_edittext });
            if(editxt==true)
                {
                string residence=tenantresidence_edittext.Text.ToString();
                string duration= tenantduration_edittext.Text.ToString();
                try
                {
                    int rent = Convert.ToInt32(tenatrent_edittext.Text.ToString());
					progressDialog = new ProgressDialog(this, Resource.Style.AppCompatDialogStyle);
					progressDialog.SetCancelable(false);
					progressDialog.SetMessage("Please wait....");
					progressDialog.SetTitle("Submiting");
					progressDialog.Indeterminate = true;
					progressDialog.Show();

					ReportSubmitImpl callback = new ReportSubmitImpl(tenantsubmit_button, progressDialog, this);
					SubmitOperationHandler.submitTenat(CommonConstans.USER, duration, residence, rent, callback);
                }catch(FormatException ex){
                    Console.WriteLine( ex.Message);
                    return;
                }
               

            }
           
        }
        private Boolean ValidateEditetxt(EditText[] edit)
        {
            for (int i = 0; i < edit.Length; i++)
                if (TextUtils.IsEmpty(edit[i].Text))
                {
                    edit[i].SetError("Can't be empty", GetDrawable(Resource.Drawable.error_ic));
                    return false;
                }
            return true;
        }
       
    }
}