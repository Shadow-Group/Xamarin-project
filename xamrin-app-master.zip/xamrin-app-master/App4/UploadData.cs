﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using Java.Net;
using System.IO;
using Java.IO;

namespace App4
{
    class UploadData :AsyncTask<String,String,String>
    {
        Dictionary<string, string> myDict;
        String type;
        private OnResult callback;
        public UploadData(Dictionary<string, string> mydictionary,string type,OnResult call)
        {
            this.myDict = mydictionary;
            this.type = type;
            this.callback = call;
           
        }

        protected override string RunInBackground(params string[] @params)
        {
			string uri = CommonConstans.URL;
			uri = uri + "op=" + type;
            foreach (var item in myDict)
			{
				uri += "&" + item.Key + "=" + item.Value;
			}
			try
			{
				URL url = new URL(uri);
                System.Console.WriteLine(url);

				HttpURLConnection connection = (HttpURLConnection)url.OpenConnection();
				BufferedReader br = new BufferedReader(new InputStreamReader(connection.InputStream));
				StringBuilder sb = new StringBuilder();
				String line;
				while ((line = br.ReadLine()) != null)
				{
					sb.Append(line);
				}
				line = sb.ToString();
				connection.InputStream.Close();
				connection.Disconnect();

				sb.Remove(0, sb.Length);
				return line;
			}
			catch (Exception ex)
			{
                System.Console.WriteLine(ex.StackTrace);
                return null;
			}

		}
        protected override void OnPostExecute(string result)
        {
            base.OnPostExecute(result);
            if(result!=null){
                callback.onSuccess(result);
            }else{
                callback.onError("Error");
            }

        }
       
    }
	public interface OnResult
	{
		void onSuccess(String result);
		void onError(String error);
	}
}