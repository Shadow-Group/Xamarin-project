﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;

namespace App4
{
    class UserDataModel
    {
        private string mUsername;
        private string mPassword;
        public UserDataModel(string username, string password)
        {
            mUsername = username;
            mPassword = password;
        
        }
        public string GetUserName()
        {
            return mUsername;
        }
        public string GetPassword()
        {
            return mPassword;
        }
    }
}