﻿using System;
using Android.OS;
using Java.Net;
using Java.IO;
using System.Text;
using Org.Json;
using System.Text.RegularExpressions;
using System.Collections.Generic;
using System.Net.Http;
using Org.Apache.Http.Impl.Client;

namespace App4
{
    public class SubmitOperationHandler
    {
        public OnResult listener;
        static string TAG="bullhead";
        static string SERVER_URL = "http://fypserver1.azurewebsites.net/?op=";
        public static void submitTenat(User user, string duration, string residence, int rent, OnReportSubmitted listener)
        {

            AsyncTask task = new Task(listener);
            task.Execute(user.getId(), user.getName(),duration, residence,rent);

        }
        public static void submitFirOrComplaint(User user,int type,String title,String description,OnReportSubmitted callback){
            AsyncTask task = new FirSubmit(callback);
            task.Execute(user.getName(),type,title,description);
        }
        public static void submitSighting(User user, String province, 
                                          string city, string area, string face,OnReportSubmitted callback){
            SightingTask task = new SightingTask(callback);
            task.Execute(user.getName(), province, city, area, face);
            
        }

        class SightingTask : AsyncTask<String, String, String>
        {
            private OnReportSubmitted listener;
            public SightingTask(OnReportSubmitted listener){
                this.listener = listener;
            }
            protected override string RunInBackground(params string[] @params)
            {
                string username = @params[0];
                string province = @params[1];
                string city = @params[2];
                string area = @params[3];
                string face = @params[4];

                face=Regex.Replace(face, @"\s+", "");

			

						string url = SERVER_URL + "submit_sight&username=" + username
                    + "&province=" + province + "&city=" + city + "&area=" + area;
                try{


                    URL url1 = new URL("http://fypserver1.azurewebsites.net/");
                    HttpURLConnection connection = (Java.Net.HttpURLConnection)url1.OpenConnection();
                    connection.RequestMethod = "POST";
                    connection.DoOutput = true;
                    connection.DoInput = true;
                    connection.Connect();
                    //

                    PrintWriter writer=new PrintWriter(connection.OutputStream);
                    writer.Write("toota="+face+"&username="+username);
                    writer.Flush();
                    writer.Close();
                    if(connection.ResponseCode==HttpStatus.Ok){
						Android.Util.Log.Debug(TAG, "Image submitted");

                    }else{
                        Android.Util.Log.Debug(TAG,"error uploading image");
                        connection.Disconnect();
                    }
                    String json = getJsonFromUrl(url);
                    return json;
                }catch(IOException ex){
                    Android.Util.Log.Debug(TAG,ex.Message);
                    return null;
                }
            }
            protected override void OnPostExecute(string json)
            {
				if (json == null)
				{
					listener.onError();
					return;
				}
				try
				{
					base.OnPostExecute(json);
					JSONObject rootObject = new JSONObject(json);
					JSONObject message = rootObject.GetJSONObject("message");
					if (message.GetInt("code") == 200)
					{
						listener.onSuccess();
					}
					else
					{
						listener.onError();
					}
				}
				catch (IOException ex)
				{
					Android.Util.Log.Debug(TAG, ex.Message);

					listener.onError();
				}
				catch (JSONException ex)
				{
					Android.Util.Log.Debug(TAG, ex.Message);

					listener.onError();
				}

			}
        }

        class FirSubmit : AsyncTask<String, String, String>
        {
            private OnReportSubmitted listener;
            public FirSubmit(OnReportSubmitted listener){
                this.listener = listener;
            }
            protected override string RunInBackground(params string[] @params)
            {
                String username = @params[0];
                int type = Convert.ToInt32(@params[1]);
                String title = @params[2];
                String description = @params[3];
                String url = SERVER_URL + "submit_fir&username=" + username + "&type="
                    + type + "&title=" + title + "&description=" + description;
                try{
                    String json = getJsonFromUrl(url);
                    return json;
                }catch(IOException ex){
					Android.Util.Log.Debug(TAG, ex.Message);
					return null;
                }

            }
            protected override void OnPostExecute(string json)
            {
				if (json == null)
				{
					listener.onError();
					return;
				}
				try
				{
					base.OnPostExecute(json);
					JSONObject rootObject = new JSONObject(json);
					JSONObject message = rootObject.GetJSONObject("message");
					if (message.GetInt("code") == 200)
					{
						listener.onSuccess();
					}
					else
					{
						listener.onError();
					}
				}
				catch (IOException ex)
				{
					Android.Util.Log.Debug(TAG, ex.Message);

					listener.onError();
				}
				catch (JSONException ex)
				{
					Android.Util.Log.Debug(TAG, ex.Message);

					listener.onError();
				}
		
            }
        }
        class Task : AsyncTask<String, String, String>
        {
            OnReportSubmitted listener;
            public Task(OnReportSubmitted listener)
            {
                this.listener = listener;
            }
            protected override String RunInBackground(params String[] @params)
            {
                int infoId = Convert.ToInt32(@params[0]);
                String username = @params[1];
                String duration = @params[2];
                String residence = @params[3];
                int rent = Convert.ToInt32(@params[4]);

                String url = SERVER_URL + "submit_tenant&infoId=" + infoId + "&duration=" + duration +
                    "&residence=" + residence + "&rent=" + rent + "&username=" + username;
                try
                {
                    String json = getJsonFromUrl(url);
                    return json;
                }
                catch (IOException ex)
                {
                    Android.Util.Log.Debug(TAG,ex.Message);
                }

                return null;
            }
            protected override void OnPostExecute(string json)
            {
                if (json == null)
                {
                    listener.onError();
                    return;
                }
                try
                {
                    base.OnPostExecute(json);
                    JSONObject rootObject = new JSONObject(json);
                    JSONObject message = rootObject.GetJSONObject("message");
                    if (message.GetInt("code") == 200)
                    {
                        listener.onSuccess();
                    }
                    else
                    {
                        listener.onError();
                    }
                }
                catch (IOException ex)
                {
					Android.Util.Log.Debug(TAG, ex.Message);

					listener.onError();
                }
                catch (JSONException ex)
                {
					Android.Util.Log.Debug(TAG, ex.Message);

					listener.onError();
                }
            }
        }

        public static String getJsonFromUrl(String ur)
        {
            try
            {
                URL url = new URL(ur);
                System.Console.WriteLine(url);

                HttpURLConnection connection = (HttpURLConnection)url.OpenConnection();
                BufferedReader br = new BufferedReader(new InputStreamReader(connection.InputStream));
                StringBuilder sb = new StringBuilder();
                String line;
                while ((line = br.ReadLine()) != null)
                {
                    sb.Append(line);
                }
                line = sb.ToString();
                connection.InputStream.Close();
                connection.Disconnect();

                sb.Remove(0, sb.Length);
                Android.Util.Log.Debug(TAG,line);
                return line;
            }
            catch (IOException ex)
            {
                Android.Util.Log.Debug(TAG,ex.Message);
                throw;
            }
        }
		
       
    }






    public interface OnReportSubmitted
    {
        void onSuccess();
        void onError();
    }

}
